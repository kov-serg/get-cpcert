#!/bin/sh

./get-cpcert samples/g2001.000    1 > samples/g2001.pem    && ./test-cert.sh samples/g2001.pem
./get-cpcert samples/g2012256.000 1 > samples/g2012256.pem && ./test-cert.sh samples/g2012256.pem
./get-cpcert samples/g2012512.000 1 > samples/g2012512.pem && ./test-cert.sh samples/g2012512.pem

rm test.txt.sig
rm test.txt
rm test-cert.txt
